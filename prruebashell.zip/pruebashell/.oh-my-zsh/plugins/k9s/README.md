# k9s plugin

This plugin adds completion support for the [k9s](https://k9scli.io).

To use it, add `k9s` to the plugins array in your zshrc file:

```zsh
plugins=(... k9s)
```
